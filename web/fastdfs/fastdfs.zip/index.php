<?php

//ddType application/x-httpd-php .htm .html
